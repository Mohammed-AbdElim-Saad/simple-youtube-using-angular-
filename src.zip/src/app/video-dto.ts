export interface VideoDto {
  videoUrl: String;
  id: string;
  title: string;
}
